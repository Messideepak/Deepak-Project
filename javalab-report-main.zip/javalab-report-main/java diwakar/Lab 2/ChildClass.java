// ChildClass.java
class ChildClass extends ParentClass {
    // Method overriding
    @Override
    public void display() {
        System.out.println("Display method in ChildClass");
    }
}
