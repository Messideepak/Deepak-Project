// Dog.java
class Dog extends Animal {
    // Implementing the abstract method
    public void sound() {
        System.out.println("Woof");
    }
}
