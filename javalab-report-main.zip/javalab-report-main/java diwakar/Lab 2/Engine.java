// Engine.java
class Engine {
    public void start() {
        System.out.println("Engine started");
    }
}
