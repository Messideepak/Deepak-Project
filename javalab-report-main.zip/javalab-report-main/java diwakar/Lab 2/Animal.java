// Animal.java
abstract class Animal {
    // Abstract method
    public abstract void sound();

    // Regular method
    public void sleep() {
        System.out.println("This animal is sleeping");
    }
}
